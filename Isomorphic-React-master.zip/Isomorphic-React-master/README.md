# Isomorphic-React using React Router

I hvae built many react apps but in this application I will use the Isomorphic Rendering in React JS for server side coding.

The code will be stored inside the folder source, which contains the main files needed for routing (routes.js) and rendering (app-client.js and server.js). It also contains 4 subfolders:

components: contains all the React components
data: contains my  data "module"
static: contains all the static files needed for our application (css, js, images, etc.) and an index.html that we will use initially to test our app.
views: contains the template that we will use from the server to render the HTML content from the server.
